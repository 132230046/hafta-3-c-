﻿namespace hafta_2_uygulama
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            AdTxt = new TextBox();
            YasTxt = new TextBox();
            AdresTxt = new TextBox();
            MesaıTxt = new TextBox();
            comboBox1 = new ComboBox();
            button1 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(94, 75);
            label1.Name = "label1";
            label1.Size = new Size(73, 20);
            label1.TabIndex = 0;
            label1.Text = "Ad Soyad";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(94, 132);
            label2.Name = "label2";
            label2.Size = new Size(30, 20);
            label2.TabIndex = 1;
            label2.Text = "Yaş";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(94, 208);
            label3.Name = "label3";
            label3.Size = new Size(47, 20);
            label3.TabIndex = 2;
            label3.Text = "Adres";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(94, 275);
            label4.Name = "label4";
            label4.Size = new Size(85, 20);
            label4.TabIndex = 3;
            label4.Text = "Mesai Saati";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(94, 336);
            label5.Name = "label5";
            label5.Size = new Size(50, 20);
            label5.TabIndex = 4;
            label5.Text = "Ünvan";
            // 
            // AdTxt
            // 
            AdTxt.Location = new Point(276, 81);
            AdTxt.Name = "AdTxt";
            AdTxt.Size = new Size(125, 27);
            AdTxt.TabIndex = 5;
            // 
            // YasTxt
            // 
            YasTxt.Location = new Point(276, 143);
            YasTxt.Name = "YasTxt";
            YasTxt.Size = new Size(125, 27);
            YasTxt.TabIndex = 6;
            // 
            // AdresTxt
            // 
            AdresTxt.Location = new Point(276, 208);
            AdresTxt.Name = "AdresTxt";
            AdresTxt.Size = new Size(125, 27);
            AdresTxt.TabIndex = 7;
            // 
            // MesaıTxt
            // 
            MesaıTxt.Location = new Point(276, 268);
            MesaıTxt.Name = "MesaıTxt";
            MesaıTxt.Size = new Size(125, 27);
            MesaıTxt.TabIndex = 8;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "İşçi", "Mühendis" });
            comboBox1.Location = new Point(276, 328);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(151, 28);
            comboBox1.TabIndex = 9;
            // 
            // button1
            // 
            button1.Location = new Point(94, 403);
            button1.Name = "button1";
            button1.Size = new Size(162, 35);
            button1.TabIndex = 10;
            button1.Text = "PERSONEL OLUŞTUR";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button1);
            Controls.Add(comboBox1);
            Controls.Add(MesaıTxt);
            Controls.Add(AdresTxt);
            Controls.Add(YasTxt);
            Controls.Add(AdTxt);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox AdTxt;
        private TextBox YasTxt;
        private TextBox AdresTxt;
        private TextBox MesaıTxt;
        private ComboBox comboBox1;
        private Button button1;
    }
}