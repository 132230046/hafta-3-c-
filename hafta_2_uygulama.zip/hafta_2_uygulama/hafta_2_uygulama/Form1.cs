namespace hafta_2_uygulama
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            {
                personal prs42 = new personal(AdTxt.Text, AdresTxt.Text, Convert.ToInt32(YasTxt.Text), Convert.ToInt32(Mesa�Txt.Text), comboBox1.Text);
                if (comboBox1.Text == "���i")


                {
                    MessageBox.Show(prs42.ucrethesapla().ToString());

                }
                else
                {
                    prs42.ucrethesapla(1000);
                }

            }
        }
    }
}

